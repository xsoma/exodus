#pragma once

class CMatchSessionOnlineHost {
public:
};

class CMatchFramework {
public:
	enum indices : size_t {
		GETMATCHSESSION = 13,
	};
};